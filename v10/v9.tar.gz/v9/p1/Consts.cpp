namespace vjezbe10
{
  
double PI = 3.14158;

} /* vjezbe10 */ 
