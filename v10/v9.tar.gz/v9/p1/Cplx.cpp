#include "Cplx.hpp"

namespace vjezbe10 {

std::string Cplx::toString() const {
  return std::to_string(re_) + "+" + std::to_string(im_) + "i";
}

}  // namespace vjezbe10
