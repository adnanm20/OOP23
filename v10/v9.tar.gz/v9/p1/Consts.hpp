#pragma once

namespace  vjezbe10
{
  
extern const double PI;

} /*  vjezbe10 */ 
