#include <iostream>

template <typename T>
T foo(T a) {
  return a.vjezbe8();
}

int main (int argc, char *argv[])
{
  std::cout << "Hello world" << std::endl;
  return 0;
}
